export default async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, {
      status: 204,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'POST, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type',
      }
    });
  }

  if (req.method !== 'POST') {
    return new Response('Method not allowed', { status: 405 });
  }

  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    return new Response(JSON.stringify({ error: 'API key no configurada' }), {
      status: 500,
      headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' }
    });
  }

  try {
    const body = await req.json();
    const { url } = body;
    if (!url) return new Response(JSON.stringify({ error: 'Falta URL' }), { status: 400, headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' } });

    const res = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'anthropic-version': '2023-06-01',
        'x-api-key': apiKey,
      },
      body: JSON.stringify({
        model: 'claude-haiku-4-5-20251001',
        max_tokens: 1000,
        tools: [{ type: 'web_search_20250305', name: 'web_search' }],
        system: `Sos un asistente que extrae datos de propiedades inmobiliarias argentinas.
Buscá la publicación y extraé los datos. Respondé SOLO con un JSON válido con estas claves (sin markdown, sin texto extra):
{"titulo":"dirección completa con barrio","precio":número en ARS sin puntos,"expensas":número o null,"m2":número o null,"amb":"Monoambiente"|"2 amb"|"3 amb"|"4 amb"|"5+ amb"|null,"geoaddr":"dirección para geocodificar, Buenos Aires"}
Si no encontrás algún dato, ponelo como null.`,
        messages: [{ role: 'user', content: `Extraé los datos de esta publicación: ${url}` }]
      })
    });

    const data = await res.json();
    const text = data.content.map(b => b.type === 'text' ? b.text : '').join('').trim();
    const clean = text.replace(/```json|```/g, '').trim();
    const parsed = JSON.parse(clean);

    return new Response(JSON.stringify(parsed), {
      status: 200,
      headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' }
    });
  } catch (e) {
    return new Response(JSON.stringify({ error: e.message }), {
      status: 500,
      headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' }
    });
  }
};

export const config = { path: '/api/parse' };
